/* connectionA.asl - Spiral exploration + leader/helper 2-block task strategy
   A1 = leader (claims task, gets block1, submits)
   A2-A5 = helpers (accept need_help, get block2, connect with leader)
   Exploration: expanding spiral with clockwise rotation */

/* ===== INITIAL BELIEFS ===== */
pursuit_steps(0).
disp_stuck(0).
nav_count(0).
goal_stuck(0).
escape_steps(0).
goal_wait(0).
my_pos(0,0).
scatter(5).
spiral_dir(e).
spiral_steps(0).
leg_len(8).
turn_count(0).
scan_cd(0).
merge_attempts(0).

/* ===== RULES ===== */
dir_to_rel(n, 0,-1).
dir_to_rel(s, 0, 1).
dir_to_rel(e, 1, 0).
dir_to_rel(w,-1, 0).

my_team(Team) :- thing(0,0,entity,Team).

connect_name(JN, SN) :- agent_sn(JN, SN).
connect_name(JN, JN) :- not agent_sn(JN, _).

kb_offset(A, M, D) :- D = A - M.

visible_disp(T, DX, DY) :- thing(DX, DY, dispenser, T).

visible_goal(GX, GY) :- goal(GX, GY).

any_known_goal(AX, AY) :- mem_goal(AX, AY).
any_known_disp(T, AX, AY) :- mem_disp(T, AX, AY).

path_blocked(DX,DY) :- thing(DX,DY,obstacle,_).
path_blocked(DX,DY) :- got_block & need_pos(BX,BY) & OX = BX+DX & OY = BY+DY & thing(OX,OY,obstacle,_).
path_blocked(DX,DY) :- got_pair_block & pair_block_dir(BX,BY) & OX = BX+DX & OY = BY+DY & thing(OX,OY,obstacle,_).

/* ===== STARTUP ===== */
!start.
+!start : .my_name(connectionA1) <- +role(leader); -+spiral_dir(n).
+!start : .my_name(connectionB1) <- +role(leader); -+spiral_dir(n).
+!start : .my_name(connectionA2) <- +role(helper); -+spiral_dir(s).
+!start : .my_name(connectionB2) <- +role(helper); -+spiral_dir(s).
+!start : .my_name(connectionA3) <- +role(helper); -+spiral_dir(e).
+!start : .my_name(connectionB3) <- +role(helper); -+spiral_dir(e).
+!start : .my_name(connectionA4) <- +role(helper); -+spiral_dir(w).
+!start : .my_name(connectionB4) <- +role(helper); -+spiral_dir(w).
+!start <- +role(helper); -+spiral_dir(n).

/* ===== NAME SHARING ===== */
+name(N) <- +my_server_name(N); .broadcast(tell, server_id(N)).
+server_id(SN)[source(JN)] <- +agent_sn(JN, SN).

/* ===== MAIN LOOP ===== */
+actionID(_) <- !update_pos; !broadcast_pos; !scan_world; !try_frame_merge; !check_task; !decide.

/* ===== FAILURE HANDLERS ===== */
-!decide <- !rand_move.
-!leader_decide <- !rand_move.
-!helper_decide <- !rand_move.
-!check_task <- true.
-!spiral <- !rand_move.
-!move_toward(_,_) <- !rand_move.
-!pick_task(_) <- true.
-!pick_task_round(_,_,_) <- true.
-!claim_task(_,_,_,_,_,_,_,_,_,_,_,_) <- true.
-!retry_task(_) <- !reset_state; skip.
-!retry_submit(_) <- !reset_state; skip.
-!update_pos <- true.
-!broadcast_pos <- true.
-!scan_world <- true.
-!try_frame_merge <- true.
-!save_disps(_,_,_) <- true.
-!save_goals(_,_,_) <- true.
-!reset_state <- true.
-!rand_move <- skip.
-!next_dir <- true.
-!free_helper <- true.

+!rand_move <- .random(R);
  if (R < 0.25) { move(n) }
  elif (R < 0.5) { move(s) }
  elif (R < 0.75) { move(e) }
  else { move(w) }.

/* ===== KB: POSITION TRACKING ===== */
+!update_pos : lastAction(move) & lastActionResult(success) &
  lastActionParams(P) & .nth(0, P, Dir) & my_pos(X,Y) <-
  if (Dir == n) { NY = Y - 1; -+my_pos(X,NY) }
  elif (Dir == s) { NY = Y + 1; -+my_pos(X,NY) }
  elif (Dir == e) { NX = X + 1; -+my_pos(NX,Y) }
  elif (Dir == w) { NX = X - 1; -+my_pos(NX,Y) }.
+!update_pos <- true.

/* ===== POSITION BROADCASTING ===== */
+!broadcast_pos : my_pos(MX,MY) <- .broadcast(tell, agent_pos(MX,MY)).
+!broadcast_pos <- true.

/* ===== KB: WORLD SCANNING (throttled) ===== */
+!scan_world : scan_cd(N) & N > 0 <- NN = N - 1; -+scan_cd(NN).
+!scan_world : my_pos(MX,MY) <-
  -+scan_cd(4);
  .findall(d(T,DX,DY), thing(DX,DY,dispenser,T), Disps);
  !save_disps(Disps, MX, MY);
  .findall(g(GX,GY), goal(GX,GY), Goals);
  !save_goals(Goals, MX, MY).
+!scan_world <- true.

+!save_disps([], _, _).
+!save_disps([d(T,DX,DY)|Rest], MX, MY) <-
  AX = MX + DX; AY = MY + DY;
  if (not mem_disp(T,AX,AY)) { +mem_disp(T,AX,AY); .broadcast(tell, share_disp(T,AX,AY)) };
  !save_disps(Rest, MX, MY).

+!save_goals([], _, _).
+!save_goals([g(GX,GY)|Rest], MX, MY) <-
  AX = MX + GX; AY = MY + GY;
  if (not mem_goal(AX,AY)) { +mem_goal(AX,AY) };
  !save_goals(Rest, MX, MY).

/* Receive shared dispenser locations (in sender's frame — convert with frame_off) */
+share_disp(T,AX,AY)[source(S)] : frame_off(OX,OY) <-
  LX = AX - OX; LY = AY - OY;
  if (not mem_disp(T,LX,LY)) { +mem_disp(T,LX,LY) }.
+share_disp(_,_,_)[source(_)] <- true.

/* ===== SIGHTING-BASED FRAME MERGE ===== */
+!try_frame_merge : frame_off(_,_) <- true.
+!try_frame_merge : role(leader) <- true.

/* Verify tentative */
+!try_frame_merge : tentative_off(TOX,TOY,FA) &
  remote_pos(FA,LX,LY) & my_pos(MX,MY) & my_team(Team) & merge_attempts(MA) <-
  PredEX = LX + TOX - MX; PredEY = LY + TOY - MY;
  .findall(e(EX,EY), (thing(EX,EY,entity,Team) & not (EX==0 & EY==0)), Ents);
  if (.member(e(PredEX,PredEY), Ents)) {
    +frame_off(TOX,TOY); -tentative_off(_,_,_); -+merge_attempts(0);
    .print("FRAME MERGED offset=(",TOX,",",TOY,")")
  } else { -tentative_off(_,_,_); MA2 = MA + 1; -+merge_attempts(MA2) }.

/* Compute tentative */
+!try_frame_merge : role(helper) & paired_with(LN) & not tentative_off(_,_,_) &
  my_team(Team) & my_pos(MX,MY) & remote_pos(LN,LX,LY) & merge_attempts(MA) <-
  .findall(e(EX,EY), (thing(EX,EY,entity,Team) & not (EX==0 & EY==0)), Ents);
  .length(Ents, NumE);
  if (NumE >= 1) {
    Idx = MA mod NumE; .nth(Idx, Ents, e(EX,EY));
    TOX = MX + EX - LX; TOY = MY + EY - LY;
    +tentative_off(TOX,TOY,LN) }.

+!try_frame_merge <- true.

/* ===== TASK MANAGEMENT ===== */
+!check_task : role(leader) & claimed_task(Name,_,_,_) & task(Name,_,_,_) <- true.
+!check_task : role(leader) & claimed_task(Name,_,_,_) & not task(Name,_,_,_) & linked <-
  -claimed_task(_,_,_,_);
  .findall(t(N,D,R,Rq), task(N,D,R,Rq), Tasks);
  !retry_task(Tasks).
+!check_task : role(leader) & claimed_task(Name,_,_,_) & not task(Name,_,_,_) <- !reset_state.
+!check_task : role(leader) & not claimed_task(_,_,_,_) <-
  .findall(t(N,D,R,Rq), task(N,D,R,Rq), Tasks);
  !pick_task(Tasks).
+!check_task <- true.

/* Two-pass task selection: prefer tasks with known dispensers */
+!pick_task(Tasks) <- !pick_task_round(Tasks, Tasks, prefer).

+!pick_task_round([], All, prefer) <- !pick_task_round(All, All, any).
+!pick_task_round([], _, any).
+!pick_task_round([t(Name,Dead,Rew,Reqs)|Rest], All, Mode) :
  step(S) & Dead - S < 40 <- !pick_task_round(Rest, All, Mode).
/* Geom1 + known disp (prefer pass) */
+!pick_task_round([t(Name,Dead,Rew,Reqs)|Rest], _, prefer) :
  .length(Reqs,Len) & Len >= 2 &
  .nth(0, Reqs, req(RX1,RY1,T1)) & .nth(1, Reqs, req(RX2,RY2,T2)) &
  dir_to_rel(_,RX1,RY1) &
  HBX = RX1 - RX2 & HBY = RY1 - RY2 & dir_to_rel(_,HBX,HBY) &
  any_known_disp(T1,_,_) <-
  HSX = 2 * RX2 - RX1; HSY = 2 * RY2 - RY1;
  !claim_task(Name,Dead,Rew,Reqs,T1,RX1,RY1,T2,HBX,HBY,HSX,HSY).
/* Geom2 + known disp (prefer pass) */
+!pick_task_round([t(Name,Dead,Rew,Reqs)|Rest], _, prefer) :
  .length(Reqs,Len) & Len >= 2 &
  .nth(0, Reqs, req(RX1,RY1,T1)) & .nth(1, Reqs, req(RX2,RY2,T2)) &
  dir_to_rel(_,RX2,RY2) &
  HBX = RX2 - RX1 & HBY = RY2 - RY1 & dir_to_rel(_,HBX,HBY) &
  any_known_disp(T2,_,_) <-
  HSX = 2 * RX1 - RX2; HSY = 2 * RY1 - RY2;
  !claim_task(Name,Dead,Rew,Reqs,T2,RX2,RY2,T1,HBX,HBY,HSX,HSY).
/* Geom1 (any pass — fallback) */
+!pick_task_round([t(Name,Dead,Rew,Reqs)|Rest], _, any) :
  .length(Reqs,Len) & Len >= 2 &
  .nth(0, Reqs, req(RX1,RY1,T1)) & .nth(1, Reqs, req(RX2,RY2,T2)) &
  dir_to_rel(_,RX1,RY1) &
  HBX = RX1 - RX2 & HBY = RY1 - RY2 & dir_to_rel(_,HBX,HBY) <-
  HSX = 2 * RX2 - RX1; HSY = 2 * RY2 - RY1;
  !claim_task(Name,Dead,Rew,Reqs,T1,RX1,RY1,T2,HBX,HBY,HSX,HSY).
/* Geom2 (any pass — fallback) */
+!pick_task_round([t(Name,Dead,Rew,Reqs)|Rest], _, any) :
  .length(Reqs,Len) & Len >= 2 &
  .nth(0, Reqs, req(RX1,RY1,T1)) & .nth(1, Reqs, req(RX2,RY2,T2)) &
  dir_to_rel(_,RX2,RY2) &
  HBX = RX2 - RX1 & HBY = RY2 - RY1 & dir_to_rel(_,HBX,HBY) <-
  HSX = 2 * RX1 - RX2; HSY = 2 * RY1 - RY2;
  !claim_task(Name,Dead,Rew,Reqs,T2,RX2,RY2,T1,HBX,HBY,HSX,HSY).
+!pick_task_round([_|Rest], All, Mode) <- !pick_task_round(Rest, All, Mode).

+!claim_task(Name,Dead,Rew,Reqs,MyT,RX,RY,HelpT,HBX,HBY,HSX,HSY) <-
  +claimed_task(Name,Dead,Rew,Reqs);
  +need_type(MyT); +need_pos(RX,RY);
  +pair_stand(HSX,HSY);
  .broadcast(tell, need_help(Name,HelpT,HBX,HBY,HSX,HSY));
  .print("Claimed:",Name," my=",MyT," helper=",HelpT).

+!retry_task([]) <- !reset_state.
+!retry_task([t(Name,Dead,Rew,Reqs)|Rest]) : step(S) & Dead - S > 20 <-
  +claimed_task(Name,Dead,Rew,Reqs).
+!retry_task([_|Rest]) <- !retry_task(Rest).

+!retry_submit([]) <- !reset_state; skip.
+!retry_submit([Name|_]) <- submit(Name).

/* ===== COMMUNICATION HANDLERS ===== */
+agent_pos(X,Y)[source(S)] : remote_pos(S,OX,OY) <-
  -+prev_remote_pos(S,OX,OY); -+remote_pos(S,X,Y).
+agent_pos(X,Y)[source(S)] <- -+remote_pos(S,X,Y).

+need_help(TaskName,BlockType,HBX,HBY,HSX,HSY)[source(LeaderName)] :
  role(helper) & not paired_with(_) <-
  +paired_with(LeaderName); +assigned_task(TaskName);
  +pair_block_type(BlockType); +pair_block_dir(HBX,HBY);
  +pair_stand(HSX,HSY);
  LRX = 0 - HSX; LRY = 0 - HSY;
  +lead_offset(LRX,LRY);
  .send(LeaderName, tell, will_help(LeaderName)).

+need_help(TaskName,BlockType,HBX,HBY,HSX,HSY)[source(LeaderName)] :
  role(helper) & paired_with(LeaderName) & assigned_task(OldTask) & not (OldTask == TaskName) <-
  !free_helper;
  +paired_with(LeaderName); +assigned_task(TaskName);
  +pair_block_type(BlockType); +pair_block_dir(HBX,HBY);
  +pair_stand(HSX,HSY);
  LRX = 0 - HSX; LRY = 0 - HSY;
  -+lead_offset(LRX,LRY);
  .send(LeaderName, tell, will_help(LeaderName)).

+need_help(_,_,_,_,_,_)[source(_)] <- true.

+will_help(_)[source(HelperName)] : role(leader) <-
  +my_partner(HelperName).

+block_ready[source(S)] : role(leader) & my_partner(S) <-
  -block_ready[source(S)]; +partner_ready; -+beacon_steps(5).

+not_you[source(S)] : role(helper) & paired_with(S) <-
  -not_you[source(S)]; -signaled; -+cooldown(3).

+link_done[source(S)] : role(helper) & paired_with(S) <-
  -link_done[source(S)]; +pair_done.

+task_abort(TaskName)[source(_)] : role(helper) & assigned_task(TaskName) <-
  !free_helper.

/* Connect-based confirmed frame merge */
+leader_frame_pos(LX,LY)[source(S)] : role(helper) & paired_with(S) &
  my_pos(MX,MY) & lead_offset(LRX,LRY) <-
  OX = MX + LRX - LX; OY = MY + LRY - LY;
  -tentative_off(_,_,_); -+frame_off(OX,OY);
  .print("FRAME CONFIRMED offset=(",OX,",",OY,")").
+leader_frame_pos(_,_)[source(_)] <- true.

/* Has frame offset: convert leader's goal to helper's frame */
+leader_at_goal(LGX,LGY)[source(S)] : role(helper) & paired_with(S) & frame_off(OX,OY) <-
  GX = LGX + OX; GY = LGY + OY;
  -+leader_goal_local(GX,GY);
  if (not leader_waiting) { +leader_waiting; -+leg_len(16); -+turn_count(0); -+spiral_steps(0) }.

/* No frame offset: just widen spiral */
+leader_at_goal(_,_)[source(S)] : role(helper) & paired_with(S) & not leader_waiting <-
  +leader_waiting; -+leg_len(16); -+turn_count(0); -+spiral_steps(0).

+leader_at_goal(_,_)[source(_)] <- true.

/* ===== SCATTER PHASE (spread agents quickly) ===== */
+!decide : scatter(N) & N > 0 & lastAction(move) &
  (lastActionResult(failed_path) | lastActionResult(failed_forbidden)) <-
  -scatter(_); !rand_move.
+!decide : scatter(N) & N > 0 & spiral_dir(Dir) <-
  NN = N - 1; -+scatter(NN); move(Dir).
+!decide : role(leader) <- !leader_decide.
+!decide : role(helper) <- !helper_decide.
+!decide <- !spiral.

/* ===== LEADER DECISIONS ===== */

/* L_submit_ok: submit succeeded */
+!leader_decide : lastAction(submit) & lastActionResult(success) <-
  .print("*** TASK COMPLETE! ***"); !reset_state; skip.

/* L_submit_retry: submit failed but connected on goal = try another */
+!leader_decide : lastAction(submit) & lastActionResult(failed_target) &
  linked & goal(0,0) <-
  .findall(Name, task(Name,_,_,_), TN); !retry_submit(TN).

/* L_submit_fail: submit failed without link = reset */
+!leader_decide : lastAction(submit) & not lastActionResult(success) & not linked <-
  !reset_state; skip.

/* L1: connected + on goal = submit */
+!leader_decide : linked & claimed_task(Name,_,_,_) & goal(0,0) <-
  submit(Name).

/* L2: connected + see goal = go */
+!leader_decide : linked & visible_goal(GX,GY) <-
  !move_toward(GX,GY).

/* L2b: connected + KB goal = navigate */
+!leader_decide : linked &
  any_known_goal(AX,AY) & my_pos(MX,MY) <-
  RX = AX - MX; RY = AY - MY; !move_toward(RX,RY).

/* L3: connected + no goal = spiral */
+!leader_decide : linked <- !spiral.

/* L4_ok: connect succeeded = mark + send frame pos */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  lastAction(connect) & lastActionResult(success) &
  my_partner(HN) & not linked & my_pos(MX,MY) <-
  +linked; .send(HN, tell, link_done); .send(HN, tell, leader_frame_pos(MX,MY)); skip.

/* L4_fail: connect failed = wait */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  lastAction(connect) & not lastActionResult(success) <- skip.

/* L5: helper ready + entity at pair_stand = CONNECT */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  my_partner(HN) & in_position[source(HN)] & need_pos(RX,RY) &
  pair_stand(HSX,HSY) & my_team(Team) & thing(HSX,HSY,entity,Team) &
  connect_name(HN, SN) <-
  -in_position[source(HN)]; connect(SN,RX,RY).

/* L5b: helper ready but NOT at pair_stand = wrong entity */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  my_partner(HN) & in_position[source(HN)] <-
  -in_position[source(HN)]; .send(HN, tell, not_you); skip.

/* L5c: stale ready from non-helper */
+!leader_decide : got_block & claimed_task(_,_,_,_) & in_position[source(_)] <-
  -in_position[source(_)]; skip.

/* L6: entity at pair_stand on goal = try connect */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  pair_stand(HSX,HSY) & my_team(Team) & thing(HSX,HSY,entity,Team) & goal(0,0) &
  my_partner(HN) & connect_name(HN, SN) & need_pos(RX,RY) <-
  connect(SN,RX,RY).

/* L7: on goal = wait, broadcast position */
+!leader_decide : got_block & claimed_task(_,_,_,_) & goal(0,0) & my_pos(MX,MY) <-
  .broadcast(tell, leader_at_goal(MX,MY)); skip.

/* L7b: beacon phase = stay still for helper frame merge */
+!leader_decide : got_block & claimed_task(_,_,_,_) & beacon_steps(N) & N > 0 <-
  N2 = N - 1; -+beacon_steps(N2); skip.

/* L8: see goal = go */
+!leader_decide : got_block & claimed_task(_,_,_,_) & visible_goal(GX,GY) <-
  -+goal_stuck(0); !move_toward(GX,GY).

/* L9: break free from stuck */
+!leader_decide : got_block & claimed_task(_,_,_,_) & escape_steps(BF) & BF > 0 <-
  BF2 = BF - 1; -+escape_steps(BF2); !spiral.

/* L10: KB goal stale */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  any_known_goal(AX,AY) & my_pos(AX,AY) & not goal(0,0) <-
  -mem_goal(AX,AY); !spiral.

/* L11: KB goal stuck > 10 */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  goal_stuck(N) & N > 10 <-
  -+goal_stuck(0); -+escape_steps(8); !spiral.

/* L12: KB goal = navigate */
+!leader_decide : got_block & claimed_task(_,_,_,_) &
  any_known_goal(AX,AY) & my_pos(MX,MY) & goal_stuck(N) <-
  RX = AX - MX; RY = AY - MY;
  N2 = N + 1; -+goal_stuck(N2); !move_toward(RX,RY).

/* L13: have block, no goal = spiral */
+!leader_decide : got_block & claimed_task(_,_,_,_) <- !spiral.

/* L14: request blocked */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  lastAction(request) & lastActionResult(failed_blocked) <- !rand_move.

/* L15: correct block attached */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & need_pos(RX,RY) &
  attached(RX,RY) & thing(RX,RY,block,T) <-
  +got_block; -+disp_stuck(0); -seek_alt(_); skip.

/* L16: at dispenser = request */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & need_pos(RX,RY) &
  thing(RX,RY,dispenser,T) & dir_to_rel(Dir,RX,RY) &
  not thing(RX,RY,block,_) <- request(Dir).

/* L17: block appeared = attach */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & need_pos(RX,RY) &
  thing(RX,RY,block,T) & dir_to_rel(Dir,RX,RY) &
  not attached(RX,RY) <- attach(Dir).

/* L18: detour from stuck dispenser */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  seek_alt(N) & N > 0 <-
  if (N > 1) { NN = N - 1; -+seek_alt(NN) } else { -seek_alt(_) };
  !spiral.

/* L19: stuck > 4 at dispenser */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  disp_stuck(N) & N > 4 <-
  -+disp_stuck(0); -+seek_alt(10); !spiral.

/* L20: see dispenser = approach correct side */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & need_pos(RX,RY) &
  visible_disp(T, DX, DY) & disp_stuck(SN) <-
  SN2 = SN + 1;
  if (DX == RX & DY == RY) { -+disp_stuck(0); skip }
  elif (DX == 0 & DY == 0) { -+disp_stuck(SN2); !rand_move }
  else { -+disp_stuck(SN2); TX = DX - RX; TY = DY - RY; !move_toward(TX,TY) }.

/* L21: KB stale disp */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & any_known_disp(T,AX,AY) & my_pos(MX,MY) &
  kb_offset(AX,MX,RX) & kb_offset(AY,MY,RY) &
  RX >= -3 & RX <= 3 & RY >= -3 & RY <= 3 & not thing(_,_,dispenser,T) <-
  -mem_disp(T,AX,AY); !spiral.

/* L22: KB nav stuck > 8 */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  nav_count(N) & N > 8 <-
  if (need_type(T) & any_known_disp(T,AX,AY)) { -mem_disp(T,AX,AY) };
  -+nav_count(0); !spiral.

/* L23: KB navigate to dispenser */
+!leader_decide : claimed_task(_,_,_,_) & not got_block &
  need_type(T) & any_known_disp(T,AX,AY) & my_pos(MX,MY) & nav_count(N) <-
  RX = AX - MX; RY = AY - MY; N2 = N + 1; -+nav_count(N2);
  !move_toward(RX,RY).

/* L24: spiral for dispenser */
+!leader_decide : claimed_task(_,_,_,_) <- !spiral.
/* L_default: no task = spiral */
+!leader_decide <- !spiral.

/* ===== HELPER DECISIONS ===== */

/* H1: help done = detach and free */
+!helper_decide : pair_done &
  pair_block_dir(HBX,HBY) & dir_to_rel(Dir,HBX,HBY) <-
  detach(Dir); !free_helper.

/* H2: connect succeeded */
+!helper_decide : got_pair_block & paired_with(_) &
  lastAction(connect) & lastActionResult(success) & not pair_done <-
  +pair_done; skip.

/* H3: connect failed */
+!helper_decide : got_pair_block & paired_with(_) &
  lastAction(connect) & not lastActionResult(success) <-
  -signaled; skip.

/* H4: sent ready + entity still there = CONNECT */
+!helper_decide : got_pair_block & paired_with(LN) &
  signaled & lead_offset(LRX,LRY) & pair_block_dir(HBX,HBY) &
  my_team(Team) & thing(LRX,LRY,entity,Team) &
  connect_name(LN, SN) <-
  connect(SN,HBX,HBY).

/* H5: sent ready but entity gone */
+!helper_decide : got_pair_block & paired_with(_) & signaled <-
  -signaled; !spiral.

/* H6: entity at lead_offset on goal = signal + connect */
+!helper_decide : got_pair_block & paired_with(LN) &
  lead_offset(LRX,LRY) & pair_block_dir(HBX,HBY) & my_team(Team) &
  thing(LRX,LRY,entity,Team) & goal(LRX,LRY) &
  connect_name(LN, SN) <-
  -+pursuit_steps(0); -+goal_wait(0); +signaled;
  .send(LN, tell, in_position);
  connect(SN,HBX,HBY).

/* H7: cooldown */
+!helper_decide : got_pair_block & paired_with(_) &
  cooldown(N) & N > 0 <-
  if (N > 1) { NN = N - 1; -+cooldown(NN) } else { -cooldown(N) };
  !spiral.

/* H8: chase timeout */
+!helper_decide : got_pair_block & paired_with(_) &
  pursuit_steps(CS) & CS > 10 <-
  -+pursuit_steps(0); !spiral.

/* H9: entity on goal = approach assembly position */
+!helper_decide : got_pair_block & paired_with(_) &
  lead_offset(LRX,LRY) & my_team(Team) &
  thing(EX,EY,entity,Team) & not (EX == 0 & EY == 0) &
  goal(EX,EY) & pursuit_steps(CS) <-
  CSN = CS + 1; -+pursuit_steps(CSN);
  MX = EX - LRX; MY = EY - LRY;
  if (MX == 0 & MY == 0) { skip } else { !move_toward(MX,MY) }.

/* H9b: continuing chase, entity visible */
+!helper_decide : got_pair_block & paired_with(_) &
  pursuit_steps(CS) & CS > 0 &
  lead_offset(LRX,LRY) & my_team(Team) &
  thing(EX,EY,entity,Team) & not (EX == 0 & EY == 0) <-
  CSN = CS + 1; -+pursuit_steps(CSN);
  MX = EX - LRX; MY = EY - LRY;
  if (MX == 0 & MY == 0) { skip } else { !move_toward(MX,MY) }.

/* H10: break free */
+!helper_decide : got_pair_block & paired_with(_) &
  escape_steps(BF) & BF > 0 <-
  BF2 = BF - 1; -+escape_steps(BF2); !spiral.

/* H11: on goal too long = blacklist + break free */
+!helper_decide : got_pair_block & paired_with(_) & goal(0,0) &
  goal_wait(GS) & GS > 6 & my_pos(MX,MY) <-
  +visited_goal(MX,MY); .abolish(mem_goal(_,_));
  -+goal_wait(0); -+escape_steps(20);
  -+leg_len(16); -+turn_count(0); -+spiral_steps(0); !spiral.

/* H12: on goal = scan for leader */
+!helper_decide : got_pair_block & paired_with(_) & goal(0,0) &
  goal_wait(GS) <-
  GS2 = GS + 1; -+goal_wait(GS2); !rand_move.

/* H13: see goal = go (skip visited) */
+!helper_decide : got_pair_block & paired_with(_) &
  visible_goal(GX,GY) & goal_wait(GS) & GS < 3 &
  my_pos(MX,MY) <-
  AGX = MX + GX; AGY = MY + GY;
  if (visited_goal(AGX,AGY)) { !spiral }
  else { -+pursuit_steps(0); !move_toward(GX,GY) }.

/* H14: KB visited goal = remove */
+!helper_decide : got_pair_block & paired_with(_) &
  any_known_goal(AX,AY) & visited_goal(AX,AY) <-
  -mem_goal(AX,AY); !spiral.

/* H15: KB goal nav stuck > 20 = blacklist */
+!helper_decide : got_pair_block & paired_with(_) &
  goal_stuck(N) & N > 20 <-
  if (any_known_goal(AX,AY)) { -mem_goal(AX,AY); +visited_goal(AX,AY) };
  -+goal_stuck(0); -+escape_steps(16);
  -+leg_len(16); -+turn_count(0); -+spiral_steps(0); !spiral.

/* H16: KB goal = navigate */
+!helper_decide : got_pair_block & paired_with(_) &
  any_known_goal(AX,AY) & my_pos(MX,MY) & goal_stuck(N) <-
  RX = AX - MX; RY = AY - MY;
  N2 = N + 1; -+goal_stuck(N2); -+pursuit_steps(0);
  !move_toward(RX,RY).

/* H16b: leader goal in our frame = navigate there */
+!helper_decide : got_pair_block & paired_with(_) &
  leader_goal_local(GX,GY) & my_pos(MX,MY) & goal_stuck(N) <-
  RX = GX - MX; RY = GY - MY;
  N2 = N + 1; -+goal_stuck(N2); -+pursuit_steps(0);
  !move_toward(RX,RY).

/* H17: no goal = spiral */
+!helper_decide : got_pair_block & paired_with(_) <-
  -+pursuit_steps(0); !spiral.

/* H18: request blocked */
+!helper_decide : paired_with(_) & not got_pair_block &
  lastAction(request) & lastActionResult(failed_blocked) <- !rand_move.

/* H19: block attached = confirm */
+!helper_decide : paired_with(LN) & not got_pair_block &
  pair_block_type(T) & pair_block_dir(HBX,HBY) &
  attached(HBX,HBY) & thing(HBX,HBY,block,T) & my_pos(MX,MY) <-
  +got_pair_block; -+disp_stuck(0); -seek_alt(_);
  -target_disp(_,_,_); -+nav_count(0);
  .send(LN, tell, block_ready); skip.

/* H20: detach stale block */
+!helper_decide : paired_with(_) & not got_pair_block &
  attached(AX,AY) & dir_to_rel(Dir,AX,AY) <- detach(Dir).

/* H21: at dispenser = request */
+!helper_decide : paired_with(_) & not got_pair_block &
  pair_block_type(T) & pair_block_dir(HBX,HBY) &
  thing(HBX,HBY,dispenser,T) & dir_to_rel(Dir,HBX,HBY) &
  not thing(HBX,HBY,block,_) <- request(Dir).

/* H22: block appeared = attach */
+!helper_decide : paired_with(_) & not got_pair_block &
  pair_block_type(T) & pair_block_dir(HBX,HBY) &
  thing(HBX,HBY,block,T) & dir_to_rel(Dir,HBX,HBY) &
  not attached(HBX,HBY) <- attach(Dir).

/* H23: detour from stuck */
+!helper_decide : paired_with(_) & not got_pair_block &
  seek_alt(N) & N > 0 <-
  if (N > 1) { NN = N - 1; -+seek_alt(NN) } else { -seek_alt(_) };
  !spiral.

/* H24: stuck > 4 */
+!helper_decide : paired_with(_) & not got_pair_block &
  disp_stuck(N) & N > 4 <-
  -+disp_stuck(0); -+seek_alt(10); !spiral.

/* H25: see dispenser = approach */
+!helper_decide : paired_with(_) & not got_pair_block &
  pair_block_type(T) & pair_block_dir(HBX,HBY) &
  visible_disp(T, DX, DY) & disp_stuck(SN) <-
  -+nav_count(0); SN2 = SN + 1;
  if (DX == HBX & DY == HBY) { -+disp_stuck(0); skip }
  elif (DX == 0 & DY == 0) { -+disp_stuck(SN2); !rand_move }
  else { -+disp_stuck(SN2); TX = DX - HBX; TY = DY - HBY; !move_toward(TX,TY) }.

/* H26: KB stale disp */
+!helper_decide : paired_with(_) & not got_pair_block &
  pair_block_type(T) & any_known_disp(T,AX,AY) & my_pos(MX,MY) &
  kb_offset(AX,MX,RX) & kb_offset(AY,MY,RY) &
  RX >= -3 & RX <= 3 & RY >= -3 & RY <= 3 & not thing(_,_,dispenser,T) <-
  -mem_disp(T,AX,AY); !spiral.

/* H27: KB nav stuck > 8 */
+!helper_decide : paired_with(_) & not got_pair_block &
  nav_count(N) & N > 8 <-
  if (pair_block_type(T) & any_known_disp(T,AX,AY)) { -mem_disp(T,AX,AY) };
  -+nav_count(0); !spiral.

/* H28: KB navigate to dispenser */
+!helper_decide : paired_with(_) & not got_pair_block &
  pair_block_type(T) & any_known_disp(T,AX,AY) & my_pos(MX,MY) & nav_count(N) <-
  RX = AX - MX; RY = AY - MY; N2 = N + 1; -+nav_count(N2);
  !move_toward(RX,RY).

/* H29: spiral for dispenser */
+!helper_decide : paired_with(_) & not got_pair_block <- !spiral.

/* H30: free helper with stale block */
+!helper_decide : not paired_with(_) & attached(AX,AY) & dir_to_rel(Dir,AX,AY) <-
  detach(Dir).

/* H_default: spiral */
+!helper_decide <- !spiral.

/* ===== BLOCK-AWARE MOVEMENT WITH DODGE ===== */
+!move_toward(0,0) <- skip.
/* Two consecutive failures = random escape */
+!move_toward(X,Y) : lastAction(move) &
  (lastActionResult(failed_path) | lastActionResult(failed_forbidden)) &
  last_dodge <- -last_dodge; !rand_move.
/* Single failure = perpendicular dodge */
+!move_toward(X,Y) : lastAction(move) &
  (lastActionResult(failed_path) | lastActionResult(failed_forbidden)) &
  lastActionParams(P) & .nth(0,P,D) <- +last_dodge;
  if ((D == n | D == s) & X > 0 & not path_blocked(1,0)) { move(e) }
  elif ((D == n | D == s) & not path_blocked(-1,0)) { move(w) }
  elif ((D == n | D == s) & not path_blocked(1,0)) { move(e) }
  elif ((D == e | D == w) & Y > 0 & not path_blocked(0,1)) { move(s) }
  elif ((D == e | D == w) & not path_blocked(0,-1)) { move(n) }
  elif ((D == e | D == w) & not path_blocked(0,1)) { move(s) }
  else { !rand_move }.
/* Primary axis movement: go toward target, prefer larger offset axis */
+!move_toward(X,Y) : X > 0 & X >= Y & X >= 0-Y & not path_blocked(1,0) <- -last_dodge; move(e).
+!move_toward(X,Y) : X < 0 & (0-X) >= Y & (0-X) >= 0-Y & not path_blocked(-1,0) <- -last_dodge; move(w).
+!move_toward(X,Y) : Y > 0 & not path_blocked(0,1) <- -last_dodge; move(s).
+!move_toward(X,Y) : Y < 0 & not path_blocked(0,-1) <- -last_dodge; move(n).
/* Fallback: try any unblocked direction toward target */
+!move_toward(X,Y) : X > 0 & not path_blocked(1,0) <- -last_dodge; move(e).
+!move_toward(X,Y) : X < 0 & not path_blocked(-1,0) <- -last_dodge; move(w).
+!move_toward(X,Y) : Y > 0 & not path_blocked(0,1) <- -last_dodge; move(s).
+!move_toward(X,Y) : Y < 0 & not path_blocked(0,-1) <- -last_dodge; move(n).
/* All blocked = random */
+!move_toward(_,_) <- -last_dodge; !rand_move.

/* ===== EXPANDING SPIRAL ===== */
/* Hit wall/obstacle = rotate and move new direction (no recursion) */
+!spiral : lastAction(move) &
  (lastActionResult(failed_path) | lastActionResult(failed_forbidden)) <-
  !next_dir; ?spiral_dir(ND); -+spiral_steps(1); move(ND).
/* Completed current leg = rotate and move new direction */
+!spiral : spiral_steps(S) & leg_len(Leg) & S >= Leg <-
  !next_dir; ?spiral_dir(ND); -+spiral_steps(1); move(ND).
/* Continue current direction */
+!spiral : spiral_dir(Dir) & spiral_steps(S) <-
  NS = S + 1; -+spiral_steps(NS); move(Dir).
/* Fallback */
+!spiral <- !rand_move.

/* Rotate clockwise, expand spiral every 2 turns */
+!next_dir : spiral_dir(Dir) & turn_count(T) & leg_len(L) <-
  -+spiral_steps(0);
  NT = T + 1; -+turn_count(NT);
  if (Dir == n) { -+spiral_dir(e) }
  elif (Dir == e) { -+spiral_dir(s) }
  elif (Dir == s) { -+spiral_dir(w) }
  else { -+spiral_dir(n) };
  if (NT mod 2 == 0) { NL = L + 4; -+leg_len(NL) }.

/* ===== EVENT HANDLERS ===== */
+lastActionResult(success) : lastAction(connect) & role(leader) & my_partner(HN) & my_pos(MX,MY) <-
  +linked; .send(HN, tell, link_done); .send(HN, tell, leader_frame_pos(MX,MY)).
+lastActionResult(success) : lastAction(connect) & role(helper) <- +pair_done.

/* ===== FREE HELPER ===== */
+!free_helper <-
  -pair_done; -paired_with(_); -assigned_task(_);
  -pair_block_type(_); -pair_block_dir(_,_);
  -pair_stand(_,_); -got_pair_block; -lead_offset(_,_);
  -signaled; -cooldown(_); -+pursuit_steps(0);
  -+disp_stuck(0); -seek_alt(_);
  -target_disp(_,_,_); -+nav_count(0); -+goal_wait(0);
  -+escape_steps(0); .abolish(visited_goal(_,_));
  -leader_waiting; -leader_goal_local(_,_); -tentative_off(_,_,_);
  -+merge_attempts(0).

/* ===== CLEAR STATE ===== */
+!reset_state : claimed_task(Name,_,_,_) <-
  .broadcast(tell, task_abort(Name));
  -claimed_task(_,_,_,_); -need_type(_); -need_pos(_,_);
  -got_block; -linked; .abolish(my_partner(_)); -partner_ready;
  -pair_stand(_,_); -in_position[source(_)]; -cooldown(_);
  .abolish(will_help(_)); .abolish(block_ready);
  -sent_leader_goal; -sent_leader_pos;
  -+disp_stuck(0); -seek_alt(_); -target_disp(_,_,_); -+nav_count(0);
  -last_dodge; -+goal_stuck(0); -+escape_steps(0); -+goal_wait(0);
  .abolish(visited_goal(_,_)); -leader_waiting;
  -leader_goal_local(_,_); -tentative_off(_,_,_);
  -+merge_attempts(0); -beacon_steps(_).
+!reset_state <-
  -claimed_task(_,_,_,_); -need_type(_); -need_pos(_,_);
  -got_block; -linked; .abolish(my_partner(_)); -partner_ready;
  -pair_stand(_,_); -in_position[source(_)]; -cooldown(_);
  .abolish(will_help(_)); .abolish(block_ready);
  -sent_leader_goal; -sent_leader_pos;
  -+disp_stuck(0); -seek_alt(_); -target_disp(_,_,_); -+nav_count(0);
  -last_dodge; -+goal_stuck(0); -+escape_steps(0); -+goal_wait(0);
  .abolish(visited_goal(_,_)); -leader_waiting;
  -leader_goal_local(_,_); -tentative_off(_,_,_);
  -+merge_attempts(0); -beacon_steps(_).
  
  
