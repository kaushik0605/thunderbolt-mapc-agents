package jason.eis.astar;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

import jason.asSemantics.DefaultInternalAction;
import jason.asSemantics.TransitionSystem;
import jason.asSemantics.Unifier;
import jason.asSyntax.ASSyntax;
import jason.asSyntax.ListTerm;
import jason.asSyntax.NumberTerm;
import jason.asSyntax.Structure;
import jason.asSyntax.Term;

/**
 * A* pathfinding internal action for Jason agents.
 *
 * Usage in AgentSpeak:
 * jason.eis.astar.FindPath(StartX, StartY, GoalX, GoalY, ObstacleList, Path)
 *
 * ObstacleList is a Jason list of obs(X,Y) terms.
 * Path is unified with a Jason list of directions e.g. [n,e,e,s]
 * Fails (returns false) if no path exists.
 */
public class FindPath extends DefaultInternalAction {

    private static final int MAX_ITERATIONS = 2000;

    @Override
    public Object execute(TransitionSystem ts, Unifier un, Term[] args) throws Exception {

        // Supports 6-arg (no block) and 8-arg (block-aware) variants
        boolean hasBlock = args.length >= 8;
        int pathIdx = hasBlock ? 7 : 5;

        int startX = (int) ((NumberTerm) args[0]).solve();
        int startY = (int) ((NumberTerm) args[1]).solve();
        int goalX  = (int) ((NumberTerm) args[2]).solve();
        int goalY  = (int) ((NumberTerm) args[3]).solve();

        // Build obstacle set from Jason list: [obs(X,Y), ...]
        Set<Long> blocked = new HashSet<>();
        Term obstacleArg = args[4];
        if (obstacleArg instanceof ListTerm) {
            ListTerm list = (ListTerm) obstacleArg;
            while (list != null && !list.isEmpty()) {
                Term head = list.get(0);
                if (head instanceof Structure) {
                    Structure s = (Structure) head;
                    int ox = (int) ((NumberTerm) s.getTerm(0)).solve();
                    int oy = (int) ((NumberTerm) s.getTerm(1)).solve();
                    blocked.add(pack(ox, oy));
                }
                Term tail = list.getTail();
                if (tail instanceof ListTerm) {
                    list = (ListTerm) tail;
                } else {
                    break;
                }
            }
        }

        // 8-arg variant: add shifted obstacles for attached block collision
        if (hasBlock) {
            int blockX = (int) ((NumberTerm) args[5]).solve();
            int blockY = (int) ((NumberTerm) args[6]).solve();
            Set<Long> extra = new HashSet<>();
            for (Long key : blocked) {
                int ox = (int) ((key >> 20) - 10000);
                int oy = (int) ((key & 0xFFFFF) - 10000);
                extra.add(pack(ox - blockX, oy - blockY));
            }
            blocked.addAll(extra);
        }

        List<String> path = astar(startX, startY, goalX, goalY, blocked);
        if (path == null) return false;

        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < path.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(path.get(i));
        }
        sb.append("]");

        return un.unifies(args[pathIdx], ASSyntax.parseTerm(sb.toString()));
    }

    private static long pack(int x, int y) {
        return ((long)(x + 10000)) << 20 | (long)(y + 10000);
    }

    private static final int[][] DIRS    = {{0,-1},{0,1},{1,0},{-1,0}};
    private static final String[] DNAMES = {"n","s","e","w"};

    private List<String> astar(int sx, int sy, int gx, int gy, Set<Long> blocked) {

        PriorityQueue<Node> open = new PriorityQueue<>(
            Comparator.comparingDouble(n -> n.f)
        );
        Map<Long, Double> best = new HashMap<>();

        double h0 = Math.abs(sx-gx) + Math.abs(sy-gy);
        open.add(new Node(sx, sy, null, null, 0, h0));
        best.put(pack(sx, sy), 0.0);

        int iter = 0;
        while (!open.isEmpty()) {
            if (++iter > MAX_ITERATIONS) break;

            Node cur = open.poll();
            long curKey = pack(cur.x, cur.y);

            Double bestG = best.get(curKey);
            if (bestG != null && cur.g > bestG) continue;

            if (cur.x == gx && cur.y == gy) return reconstruct(cur);

            for (int i = 0; i < DIRS.length; i++) {
                int nx = cur.x + DIRS[i][0];
                int ny = cur.y + DIRS[i][1];
                long nkey = pack(nx, ny);

                // CRITICAL FIX: Ignore the obstacle if it is the exact target cell
                if (blocked.contains(nkey) && !(nx == gx && ny == gy)) continue;

                double ng = cur.g + 1;
                if (ng >= best.getOrDefault(nkey, Double.MAX_VALUE)) continue;

                best.put(nkey, ng);
                double h = Math.abs(nx-gx) + Math.abs(ny-gy);
                open.add(new Node(nx, ny, cur, DNAMES[i], ng, ng+h));
            }
        }
        return null;
    }

    private List<String> reconstruct(Node goal) {
        LinkedList<String> path = new LinkedList<>();
        for (Node n = goal; n.dir != null; n = n.parent) path.addFirst(n.dir);
        return path;
    }

    private static class Node {
        int x, y;
        Node parent;
        String dir;
        double g, f;

        Node(int x, int y, Node parent, String dir, double g, double f) {
            this.x=x; this.y=y; this.parent=parent;
            this.dir=dir; this.g=g; this.f=f;
        }
    }
}